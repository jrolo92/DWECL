import {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
} from "./chunk-GWYSNQV4.js";
import "./chunk-O5BH2LI2.js";
import "./chunk-TSFBIFCB.js";
import "./chunk-FEOQ3O24.js";
import "./chunk-TWB3JXGJ.js";
import "./chunk-QCYASZNG.js";
import "./chunk-LHTYEYWE.js";
import "./chunk-ONF4LMPL.js";
import "./chunk-32TWKTD6.js";
import "./chunk-EZT2A2HU.js";
import "./chunk-DUTPFSDB.js";
import "./chunk-7ETHIT5S.js";
export {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
};
