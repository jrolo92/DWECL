import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
} from "./chunk-UTHW6V3D.js";
import "./chunk-DSMSZILQ.js";
import "./chunk-3YX3VALW.js";
import "./chunk-TH3TEXMD.js";
import "./chunk-IGZC3SG6.js";
import "./chunk-2QO4BTPD.js";
import "./chunk-SXKSVD53.js";
import "./chunk-V44ONS77.js";
import "./chunk-WM7KXEAB.js";
import "./chunk-AZECUNPL.js";
import "./chunk-UHKVW4MY.js";
import "./chunk-RUNCRWAX.js";
import "./chunk-6DU2HRTW.js";
export {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
};
